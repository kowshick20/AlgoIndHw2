import csv
import threading
import os
from LinkedList import LinkedList, Node
from Student import Student


def convert_bool(param):
    if param == "yes":
        return True
    else:
        return False


def convert_to_student(row):
    line = list(row)
    return Student(line[0], line[1], int(line[2]), line[3], line[4], line[5],
                   int(line[6]), int(line[7]), line[8], line[9], line[10], line[11],
                   int(line[12]), int(line[13]), int(line[14]), convert_bool(line[15]), convert_bool(line[16]),
                   convert_bool(line[17]), convert_bool(line[18]), convert_bool(line[19]),
                   convert_bool(line[20]), convert_bool(line[21]), convert_bool(line[22]), int(line[23]), int(line[24]),
                   int(line[25]), int(line[26]),
                   int(line[27]), int(line[28]), int(line[29]), convert_bool(line[30]))

# Memory database class that does:
# a) load the student-data. csv file into the memory database through recursive function.
# b) When a row is added or removed from the CSV file, the memory database will adapt to the changes.
# c) export the memory database into a csv file through recursive function.
class MemoryDatabase:
    FILENAME = "student-data.csv"
    OUTFILE = "student-op-data.csv"


    def read(self, current_node, input_csv):
        row = next(input_csv,None)
        if row is None:
            return -1
        student = convert_to_student(row)
        return self.read(list.insert(current_node, student,None),input_csv)


    #Constructor based dependency injection
    def __init__(self):
        self.list = LinkedList()
        self.running =True
        self.prev_node=None

    def run(self):
        with open(self.FILENAME, newline="") as inputFile:
            input_csv = csv.reader(inputFile)
            header = next(input_csv, None)  # read the Header of the csv
            self.read(self.list.head, input_csv) #Read the student details from the file and add it to the linked list
        print('enter 0 to stop watching') #KeyBoard interrupt to signal make watcher thread to stop and join back to the main
        watcher_thread = threading.Thread(self.file_watcher()) #Load the watcher method to the watcherThread
        watcher_thread.start() #Start the watcher thread

        watcher_thread.join() #Resume after the completion of watcher thread

        with open(self.OUTFILE, mode='a', newline="") as outputFile:
            output_csv_writer = csv.writer(outputFile)
            output_csv_writer.writerow(header)  #print the Header of the csv
            self.printer(self.list.head, output_csv_writer) #Method to print the traverse the Linked list and print in the csv

    #     Recursively prints the student data to the csv file
    # Params:
    # current – : Accepts the current NOde/ pointer of the Linked List
    # output_csv_writer – : Accepts the Printer writer object
    # Returns:
    # : return the completion status of the printing action
    def printer(self, current, output_csv_writer):
        row = current.student.__str__()
        output_csv_writer.writerow(row)
        if current.next is None:
            return 0
        return self.printer(current.next,output_csv_writer)

    #Watches for any changes in the csv file
    def file_watcher(self):
        last_modified = None
        if os.path.exists(self.FILENAME):
            last_modified = os.path.getmtime(self.FILENAME)

        while self.running: #run the loop until the condition variable is true
            if os.path.exists(self.FILENAME):
                current_modified = os.path.getmtime(self.FILENAME)
                if last_modified is None or current_modified!=last_modified:
                    print("changes detected")
                    with open(self.FILENAME, mode='r' , newline='') as modified_file:
                        modified_csv = csv.reader(modified_file)
                        next(modified_csv) #skip header
                        self.reload(self.list.head,modified_csv) #Reload only the changes
                        last_modified=current_modified
            if input()=='0':
                self.running=False


    def reload(self,current_node,input_csv):
        row = next(input_csv)
        # When both the linked list and file is not at the end,
        # i.e. insertion/deletion happens at head in the middle
        if current_node.next is not None and row is not None:
            new_student = convert_to_student(row)
            #There is a change in the current node and the file row, investigate further
            if not new_student.__eq__(current_node.student):
                next_node = current_node.next
                # if the current node is the last or if the next node is same as the current row,
                # then the current row has been deleted, so we need to delete current node
                if next_node.next is None or next_node.student.__eq__(new_student):
                    self.list.delete(self.prev_node,next_node) #deletion operation
                else:
                    self.list.insert(self.prev_node,new_student,next_node) #Insertion operation

            self.prev_node = current_node #Store the current node
            return self.reload(current_node.next,input_csv) #recursively call with the next node and reader object
        # If the linked list has reached its end but not the file,
        # then there is something to be inserted at the end of the Linked list
        elif current_node.next is None and row is not None:
            new_student = convert_to_student(row)
            new_node = self.list.insert(self.prev_node,new_student,None)
            self.prev_node = new_node  #Store the current node
            return self.reload(new_node,input_csv) #recursively call with the next node and reader object
        # If the File has reached its end and not the Linked List,
        # there is something to be deleted from the end of the LinkedList
        elif current_node.next is not None:
            self.list.delete(self.prev_node,None)
            # No need to recursively call since we need to delete everything that are excess
        return 0   #both File and Linked list has reached the end




if __name__ == '__main__':
    db = MemoryDatabase()
    db.run()
