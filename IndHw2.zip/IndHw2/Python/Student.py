class Student:
    def __init__(self, school,
                 sex,
                 age,
                 address,
                 famSize,
                 pStatus,
                 medu,
                 fedu,
                 mJob,
                 fJob,
                 reason,
                 guardian,
                 travelTime,
                 studyTime,
                 failures,
                 schoolsUp,
                 farmsUp,
                 paid,
                 activities,
                 nursery,
                 higher,
                 internet,
                 romantic,
                 famRel,
                 freeTime,
                 goOut,
                 dalc,
                 walc,
                 health,
                 absence,
                 passed):
        self.school = school
        self.sex = sex
        self.age = age
        self.address = address
        self.famSize = famSize
        self.pStatus = pStatus
        self.medu = medu
        self.fedu = fedu
        self.mJob = mJob
        self.fJob = fJob
        self.reason = reason
        self.guardian = guardian
        self.travelTime = travelTime
        self.studyTime = studyTime
        self.failures = failures
        self.schoolsUp = schoolsUp
        self.farmsUp = farmsUp
        self.paid = paid
        self.activities = activities
        self.nursery = nursery
        self.higher = higher
        self.internet = internet
        self.romantic = romantic
        self.famRel = famRel
        self.freeTime = freeTime
        self.goOut = goOut
        self.dalc = dalc
        self.walc = walc
        self.health = health
        self.absence = absence
        self.passed = passed

    def __str__(self):
        return [self.school, self.sex, self.age, self.address, self.famSize, self.pStatus, self.medu, self.fedu,
                self.mJob, self.fJob, self.reason, self.guardian, self.travelTime, self.studyTime, self.failures,
                self.schoolsUp, self.farmsUp, self.paid, self.activities, self.nursery, self.higher, self.internet,
                self.romantic, self.famRel, self.freeTime, self.goOut, self.dalc, self.walc, self.health, self.absence,
                self.passed]

    def __eq__(self, obj):
        if not isinstance(obj, Student):
            return False
        return (self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school and
                self.school == obj.school)
